const express = require('express');
const fs = require('fs');
const https = require('https');
const socketIo = require('socket.io');

const app = express();
const options = {
  key: fs.readFileSync('server.key'),
  cert: fs.readFileSync('server.cert'),
};

const server = https.createServer(options, app);
const io = socketIo(server);

app.use(express.static('public'));

let queue = []; // Queue to hold users waiting for a partner
let liveUsers = 0; // Track number of live users

io.on('connection', (socket) => {
  liveUsers++; // Increment live user count
  io.emit('liveUsers', liveUsers); // Broadcast updated user count
  console.log(`A user connected: ${socket.id}. Total users: ${liveUsers}`);

  // Handle user ready event for matching
  socket.on('ready', () => {
    addToQueue(socket); // Add the user to the queue and attempt matching
  });

  // Handle user leaving the current match
  socket.on('leave', () => {
    console.log(`User ${socket.id} left the match.`);
    removeFromQueue(socket); // Remove the user from the queue
    addToQueue(socket); // Add the user back to the queue and attempt rematching
  });

  // Relay SDP offer/answer
  socket.on('offerOrAnswer', (data) => {
    console.log(`Relaying offer/answer from ${socket.id} to ${data.targetId}`);
    const targetSocket = io.sockets.sockets.get(data.targetId);
    if (targetSocket) {
      targetSocket.emit('offerOrAnswer', {
        sdp: data.sdp,
        from: socket.id,
      });
    }
  });

  // Relay ICE candidates
  socket.on('iceCandidate', (data) => {
    console.log(`Relaying ICE candidate from ${socket.id} to ${data.targetId}`);
    const targetSocket = io.sockets.sockets.get(data.targetId);
    if (targetSocket) {
      targetSocket.emit('iceCandidate', {
        candidate: data.candidate,
        from: socket.id,
      });
    }
  });

  // Handle user disconnection
  socket.on('disconnect', () => {
    liveUsers--; // Decrement live user count
    io.emit('liveUsers', liveUsers); // Broadcast updated user count
    console.log(`A user disconnected: ${socket.id}. Total users: ${liveUsers}`);
    removeFromQueue(socket); // Remove the user from the queue if they were waiting
  });
});

// Add a user to the queue and attempt matching
function addToQueue(socket) {
  queue.push(socket); // Add the user to the end of the queue
  attemptMatch(); // Try to match users from the queue
}

// Remove a user from the queue
function removeFromQueue(socket) {
  queue = queue.filter((s) => s !== socket); // Remove the user from the queue
}

// Attempt to match users from the queue
function attemptMatch() {
  while (queue.length >= 2) {
    const user1 = queue.shift(); // Get the first user in the queue
    const user2 = queue.shift(); // Get the second user in the queue
    user1.emit('matched', user2.id); // Notify user1 of the match
    user2.emit('matched', user1.id); // Notify user2 of the match
    console.log(`Matched users: ${user1.id} <--> ${user2.id}`);
  }
}

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Signaling server is running on https://localhost:${PORT}`);
});
